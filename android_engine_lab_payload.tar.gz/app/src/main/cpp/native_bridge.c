#define _POSIX_C_SOURCE 200809L
#include <jni.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "odm_spine.h"
#include "odm_status.h"
#include "odm_version.h"
#include "selftest.h"
#include "odpar_lab_scene.h"

static _Thread_local char g_last_error[512];

static jstring jstr(JNIEnv *env, const char *s) {
    return (*env)->NewStringUTF(env, s ? s : "");
}

static char *spine_json(odm_status (*fn)(char *, size_t, size_t *)) {
    size_t required = 0;
    odm_status st = fn(NULL, 0u, &required);
    char *buf;
    if (st != ODM_STATUS_BUFFER_TOO_SMALL || required == 0u) return NULL;
    buf = (char *)malloc(required);
    if (!buf) return NULL;
    st = fn(buf, required, &required);
    if (st != ODM_STATUS_OK) { free(buf); return NULL; }
    return buf;
}

JNIEXPORT jstring JNICALL
Java_com_odpar_musicmotionlab_MainActivity_nativeEngineInfo(JNIEnv *env, jobject thiz) {
    (void)thiz;
    char *summary = spine_json(odm_spine_summary_json);
    char out[4096];
    snprintf(out, sizeof(out),
             "ODPAR: Music Motion\nversion=%s\nabi=%u\nsource=%s\ncompiler=%s\n\n%s",
             odm_version_string(), odm_abi_version(), odm_source_id(), odm_compiler_id(),
             summary ? summary : "{\"spine\":\"unavailable\"}");
    free(summary);
    return jstr(env, out);
}

JNIEXPORT jstring JNICALL
Java_com_odpar_musicmotionlab_MainActivity_nativeSelfTest(JNIEnv *env, jobject thiz) {
    (void)thiz;
    odm_selftest_result r;
    odm_status st = odm_selftest_run(&r);
    char out[1024];
    snprintf(out, sizeof(out),
             "{\"schema\":\"odm_selftest_v1\",\"checks\":%u,\"passed\":%u,"
             "\"failed\":%u,\"status\":\"%s\",\"failed_check\":%s,\"error\":\"%s\"}",
             r.checks, r.passed, r.checks-r.passed,
             st==ODM_STATUS_OK?"pass":"fail",
             r.failed_check ? "\"present\"" : "null",
             odm_status_name(st==ODM_STATUS_OK?ODM_STATUS_OK:r.failure_status));
    return jstr(env, out);
}

JNIEXPORT jstring JNICALL
Java_com_odpar_musicmotionlab_MainActivity_nativeSpineReport(JNIEnv *env, jobject thiz) {
    (void)thiz;
    char *report = spine_json(odm_spine_report_json);
    jstring out;
    if (!report) return jstr(env, "{\"error\":\"spine report unavailable\"}");
    out = jstr(env, report);
    free(report);
    return out;
}

JNIEXPORT jintArray JNICALL
Java_com_odpar_musicmotionlab_MainActivity_nativeRenderScene(
    JNIEnv *env, jobject thiz, jint width, jint height, jdouble yaw, jdouble pitch,
    jdouble distance, jdouble phase, jboolean shadows) {
    (void)thiz;
    uint64_t pixels;
    uint8_t *rgba;
    jint *argb;
    jintArray arr;
    uint64_t fragments=0;
    uint64_t i;
    if (width<=0 || height<=0 || width>2048 || height>2048) {
        snprintf(g_last_error,sizeof(g_last_error),"invalid dimensions");
        return NULL;
    }
    pixels=(uint64_t)(uint32_t)width*(uint64_t)(uint32_t)height;
    if (pixels > SIZE_MAX/4u) { snprintf(g_last_error,sizeof(g_last_error),"size overflow"); return NULL; }
    rgba=(uint8_t*)malloc((size_t)pixels*4u);
    argb=(jint*)malloc((size_t)pixels*sizeof(jint));
    if(!rgba||!argb){free(rgba);free(argb);snprintf(g_last_error,sizeof(g_last_error),"frame allocation failed");return NULL;}
    if(!odpar_lab_render_scene(rgba,(uint32_t)width,(uint32_t)height,yaw,pitch,distance,phase,
                               shadows?1:0,&fragments,g_last_error,sizeof(g_last_error))){
        free(rgba);free(argb);return NULL;
    }
    for(i=0;i<pixels;i++) {
        const uint8_t *p=rgba+i*4u;
        argb[i]=(jint)(((uint32_t)p[3]<<24)|((uint32_t)p[0]<<16)|((uint32_t)p[1]<<8)|(uint32_t)p[2]);
    }
    free(rgba);
    arr=(*env)->NewIntArray(env,(jsize)pixels);
    if(!arr){free(argb);snprintf(g_last_error,sizeof(g_last_error),"JNI array allocation failed");return NULL;}
    (*env)->SetIntArrayRegion(env,arr,0,(jsize)pixels,argb);
    free(argb);
    snprintf(g_last_error,sizeof(g_last_error),"ok; fragments=%llu",(unsigned long long)fragments);
    return arr;
}

JNIEXPORT jstring JNICALL
Java_com_odpar_musicmotionlab_MainActivity_nativeLastError(JNIEnv *env, jobject thiz) {
    (void)thiz; return jstr(env,g_last_error);
}

JNIEXPORT jstring JNICALL
Java_com_odpar_musicmotionlab_MainActivity_nativeStressTest(
    JNIEnv *env, jobject thiz, jint frames, jint size, jboolean shadows) {
    (void)thiz;
    struct timespec a,b;
    uint8_t *rgba;
    int i, ok=0;
    uint64_t total_fragments=0;
    double seconds, fps;
    char err[512]={0};
    char out[1024];
    if(frames<1)frames=1; if(frames>240)frames=240;
    if(size<128)size=128; if(size>768)size=768;
    rgba=(uint8_t*)malloc((size_t)size*(size_t)size*4u);
    if(!rgba)return jstr(env,"{\"status\":\"fail\",\"error\":\"allocation\"}");
    clock_gettime(CLOCK_MONOTONIC,&a);
    for(i=0;i<frames;i++) {
        uint64_t f=0;
        double phase=(double)i/(double)(frames?frames:1);
        if(!odpar_lab_render_scene(rgba,(uint32_t)size,(uint32_t)size,25.0+phase*80.0,-10.0,
                                   5.2,phase,shadows?1:0,&f,err,sizeof(err))) break;
        total_fragments+=f; ok++;
    }
    clock_gettime(CLOCK_MONOTONIC,&b);
    free(rgba);
    seconds=(double)(b.tv_sec-a.tv_sec)+(double)(b.tv_nsec-a.tv_nsec)/1000000000.0;
    fps=seconds>0.0?(double)ok/seconds:0.0;
    snprintf(out,sizeof(out),
             "{\"status\":\"%s\",\"frames_requested\":%d,\"frames_rendered\":%d,"
             "\"size\":%d,\"shadows\":%s,\"seconds\":%.6f,\"fps\":%.3f,"
             "\"total_fragments\":%llu,\"error\":\"%s\"}",
             ok==frames?"pass":"fail",frames,ok,size,shadows?"true":"false",seconds,fps,
             (unsigned long long)total_fragments,ok==frames?"":err);
    return jstr(env,out);
}
