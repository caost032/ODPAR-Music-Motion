# ODPAR Music Motion — Android Engine Lab

This APK is a private test surface over the official ODPAR Music Motion C11 engine.
The build workflow downloads canonical Drive file ID `117etA7LrenJFEpgzYeRhD19T_jlY-TmA`,
verifies SHA-256 `64d786ca5850519a324d2aff70f26134ac25ff4edb959da943e093f82cc47fc8`,
and refuses to build if the production C surface is not exactly 182 non-CLI sources.

The 3D viewport is rasterized by ODPAR Scene3D (`odm_raster3d_*`), not by Android/OpenGL.
Android is UI + JNI + framebuffer presentation only.
